if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/raylib-game-template/sw.js');
}
